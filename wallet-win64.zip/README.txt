RCoinX Instructions:

1. for the GUI wallet, just open tkwallet.exe and you're ready

Notes:

The "Mining" menu in the GUI allows you to start the miner.
