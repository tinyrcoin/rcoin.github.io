RCoinX Instructions:

1. for the GUI wallet, just run "StartTkWallet.cmd" and you're ready

Notes:

The "Mining" menu in the GUI allows you to start the miner.

To use the CLI wallet, please check the website instructions.
